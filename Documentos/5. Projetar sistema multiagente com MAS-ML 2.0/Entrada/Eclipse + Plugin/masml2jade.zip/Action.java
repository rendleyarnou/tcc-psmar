package masml2jade;

import java.io.Serializable;

public interface Action extends Serializable {
	public Serializable doAction(Environment env, Object[] params);
}
