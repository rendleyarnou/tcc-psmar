package masml2jade;

import java.util.Hashtable;
import jade.core.Agent;
import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.core.Runtime;
import jade.core.behaviours.SimpleBehaviour;
import jade.wrapper.AgentContainer;
import jade.wrapper.AgentController;

public class Environment extends Agent {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Hashtable<String, Action> actions = new Hashtable<String, Action>();
	protected Hashtable<String, AgentConfiguration> agents = new Hashtable<String, AgentConfiguration>();
	private AgentContainer container;
	private String ID;
	private Profile profile;
	private Object initialResource;
	private EnvironmentConfiguration configuration;
	
	public EnvironmentConfiguration getConfiguration() {
		return configuration;
	}
	
	public void setInitialResource(Object resource) {
		this.initialResource = resource;
	}
	
	public Object getInitialResource() {
		return initialResource;
	}

	public Profile getProfile() {
		return profile;
	}
	
	public String getID() {
		return ID;
	}
	
	public AgentContainer getContainer() {
		return container;
	}

	public Action getAction(String action) {
		return this.actions.get(action);
	}

	public void sendPercept(String agent, String percept) {
		
	}

	public boolean addAgent(String name, IAgent agent) {
		if (container == null) {
			throw new IllegalStateException("Environment not initialized!");
		}
			
		try {
			AgentController ac = this.container.acceptNewAgent(name, agent);
			AgentConfiguration config = new AgentConfiguration();
			config.setAgentController(ac);
			config.setName(agent.getLocalName());
			
			ac.start();
			
			config.setAID(agent.getAID());
			
			config.setType(agent.getClass().toString());
			
			agents.put(config.getName(), config);
			
			return true;
		} catch(Exception e) {
			e.printStackTrace();
			return false;
		}		
	}
	
	public boolean addAgent(AgentConfiguration agent) {
		if (container == null) {
			throw new IllegalStateException("Environment not initialized!");
		}
			
		try {
			AgentController ac = this.container.createNewAgent(agent.getName(), agent.getType(), agent.getArguments());
			agent.setAgentController(ac);
			ac.start();
			
			agents.put(agent.getName(), agent);
			
			return true;
		} catch(Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	public boolean removeAgent(String name) {
		AgentController ac = agents.get(name).getAgentController();
		try {
			ac.kill();
			agents.remove(name);
			return true;
		} catch(Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public void addAction(String id, Action action) {
		this.actions.put(id, action);
	}

	public Action removeAction(String id) {
		return this.actions.remove(id);
	}

	public void makeEnvironment(EnvironmentConfiguration config, boolean isMainContainer, Object resource) {
		Runtime rt = Runtime.instance();
		try {
			Profile profile = null;
			this.setEnabledO2ACommunication(true, 0);
			this.setO2AManager(new ReceiveResourceBehavior(this));
			AgentController environment;
			if (!isMainContainer){
				profile = new ProfileImpl(config.getHost(), config.getPort(), config.getID());
				this.container = rt.createAgentContainer(profile);
				this.profile = profile;
				this.ID = config.getID();
				environment = container.acceptNewAgent(this.ID, this);
				environment.start();
				
			} else {
				profile = new ProfileImpl(config.getHost(), config.getPort(), config.getID());
				this.container = rt.createMainContainer(profile);
				this.ID = config.getID();
				this.profile = profile;
				
			    AgentController rma = container.createNewAgent("rma", "jade.tools.rma.rma", new Object[0]);			    
			    rma.start();   

			    environment = container.acceptNewAgent(this.ID, this);
			    environment.start();   
			}

			configuration = config;
			environment.putO2AObject(resource, false);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	protected void setup() {
		super.setup();
		addBehaviour(new ExecuteEnvironmentAction(this, 100));
		initialize();
	}
	
	public void initialize() {
		//implements in children classes
	}
	
	  // Simple class behaving as a Condition Variable
	public static class CondVar {
		private boolean value = false;

		synchronized void waitOn() throws InterruptedException {
			while (!value) {
				wait();
			}
		}

		synchronized void signal() {
			value = true;
			notifyAll();
		}

	} // End of CondVar class
	
}


class ReceiveResourceBehavior extends SimpleBehaviour {
	private Agent agent;
	private Object resource;

	public ReceiveResourceBehavior(Agent a) {
		this.agent = a;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 5662378089326169535L;

	@Override
	public void action() {
		resource = this.agent.getO2AObject();
		((Environment)this.agent).setInitialResource(resource);
	}

	@Override
	public boolean done() {
		if (resource != null) {
			return true;
		} else {
			return false;
		}
	}
}

