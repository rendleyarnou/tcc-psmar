package masml2jade.behaviour;

import jade.core.behaviours.Behaviour;

public class ReativoConhecimentoBehaviour extends Behaviour {

	@Override
	public void action() {
		// Regras condi��o-a��o

	}

	@Override
	public boolean done() {
		// TODO Auto-generated method stub
		return false;
	}

}
