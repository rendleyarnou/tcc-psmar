/**
 * 
 */
package masml2jade.agent;

import java.util.ArrayList;
import java.util.List;

import masml2jade.behaviour.ReativoBehaviour;

import jade.core.Agent;

/**
 * @author Administrator
 * 
 */
public class AgenteReativo extends MAS_Agent {

	// Perceive List
	protected List<String> perceives = new ArrayList<String>();

	// Precondition List
	protected List<String> preconditionList = new ArrayList<String>();

	// Put agent initializations here
	protected void setup() {
		super.setup();

		// Ambiente
		this.getAID().getName(); // PlatformID

		// Organiza��o
		this.getAID().getName(); // ContainerID

		// Papel de agente
		// Agente Reativo simples, possui somente comportamento
		ReativoBehaviour behaviour = new ReativoBehaviour();
		this.addBehaviour(behaviour);

	}

	// Put agent clean-up operations here
	protected void takeDown() {

	}

	@Override
	protected void initialize() {
		// TODO Auto-generated method stub

	}
}
