/**
 * 
 */
package masml2jade.agent;

import java.util.ArrayList;
import java.util.List;

import masml2jade.behaviour.ReativoBehaviour;

import jade.core.Agent;

/**
 * @author Administrator
 *
 */
public class AgenteObjetivo extends AgenteReativoConhecimento {
	
	// Goal List
	protected List<String> goals = new ArrayList<String>();
	
	// Next Function
	protected String nextFunction = new String();
	
	// Put agent initializations here
	  protected void setup() {
		  // Papel de agente
		  // Agente Reativo simples, possui somente comportamento
		  ReativoBehaviour behaviour = new ReativoBehaviour();
		  this.addBehaviour(behaviour);
		  
	  }
	
	  // Put agent clean-up operations here
	  protected void takeDown() {
		  
	  }
}
