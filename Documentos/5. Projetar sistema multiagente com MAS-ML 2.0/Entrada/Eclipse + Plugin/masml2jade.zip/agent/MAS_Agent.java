package masml2jade.agent;

import java.util.Hashtable;

import anote2jade.Scenario;
import jade.core.AID;
import jade.core.Agent;
import jade.core.PlatformID;
import jade.core.behaviours.Behaviour;

public abstract class MAS_Agent extends Agent {
	
	private Hashtable<String, Behaviour> behaviours = new Hashtable<String, Behaviour>();

	public Behaviour getBehaviours(String desc) {
		return behaviours.get(desc);
	}

	public Behaviour removeBehaviours(String desc) {
		return behaviours.remove(desc) ;
	}

	// Put agent initializations here
	protected void setup() {
		super.setup();
		this.setEnabledO2ACommunication(true, 0);
		initialize();

		// Ambiente
		this.getAID().getName(); // PlatformID

		// Organiza��o
		this.getAID().getName(); // ContainerID

		// Papel de Agente (muda cren�as e objetivos dos agentes)
		// Algum behaviour

		// Agente Reativo simples, possui somente comportamento

	}

	// Put agent clean-up operations here
	protected void takeDown() {

	}
	
	protected abstract void initialize();

}
