/**
 * 
 */
package masml2jade.agent;

import java.util.ArrayList;
import java.util.List;

import masml2jade.behaviour.ReativoBehaviour;

import jade.core.Agent;

/**
 * @author Administrator
 *
 */
public class AgenteReativoConhecimento extends AgenteReativo {
	
	// Belief List
	protected List<String> beliefs = new ArrayList<String>();
	
	// Next Function Field
	protected String nextFunction = new String();
	
	// Next Function Method
	protected void nextFunction() {
		
	}
	
	// Put agent initializations here
	  protected void setup() {
		  super.setup();
		  
		  // Ambiente
		  this.getAID().getName(); // PlatformID
		  
		  // Organiza��o
		  this.getAID().getName(); // ContainerID
		  
		  // Papel de agente
		  // Agente Reativo simples, possui somente comportamento
		  ReativoBehaviour behaviour = new ReativoBehaviour();
		  this.addBehaviour(behaviour);
		  
	  }
	
	  // Put agent clean-up operations here
	  protected void takeDown() {
		  
	  }
}
